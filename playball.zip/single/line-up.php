<section class="lineUp lineUpSubUno">
	<h2>
		LOS HITS
	</h2>
	<ol class="lineUpDia lineUpsubDos">
        <?php

            function filter_where( $where = '' ) {

            $where .= " AND post_date > '" . date('Y-m-d', strtotime('-7 days')) . "'";

            return $where;

        }

        add_filter( 'posts_where', 'filter_where' );

        $args = array(

            'meta_key' => 'prize',

            'orderby' => 'meta_value_num',

            'order' => 'DESC',
            
            'posts_per_page' => 9

                );

        $query = new WP_Query($args);

        remove_filter( 'posts_where', 'filter_where' );
        ?>
        <?php $contador = 1; ?>
        <?php while ($query->have_posts()) : $query->the_post(); ?>
        	<?php if($contador == 1){ ?>
        		<div class="lineUpUno lineUpSubTres">
            <?php } elseif ($contador == 9) { ?>
                <div class="lineUpDos lineUpCuatro">
            <?php } ?>
            <li>
                <div class="numero">
                    <?php echo $contador; ?>
                </div>
                <a href="<?php echo get_permalink(); ?>" title="<?php the_title(); ?>">
                	<?php the_title(); ?>
            	</a>
        	</li>
        	<?php if($contador == 1 || $contador == 9){ ?>
        		</div>
        	<?php } ?>
        	<?php  $contador++; ?>
    	<?php endwhile; ?>
	</ol>
    <!-- Termina lineUpDia -->
</section>
<!-- Termina lineUp -->