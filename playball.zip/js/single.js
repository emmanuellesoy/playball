$(document).ready(function()
{
	var h = parseInt($('.cuadroUno a').css('height'));
	var mar = 385 - h;
	$('.cuadroUno a').css('margin-top', mar);
});