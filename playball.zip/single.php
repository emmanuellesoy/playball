<?php get_header(); ?>
<section class="contieneTodo">
	<div class="contieneTodoFondo">
		<?php get_template_part('single/nota', 'interna'); ?>
		<?php get_template_part('general/footer', 'general'); ?>
	</div><!-- Termina contieneTodoFondio -->
</section><!--Termina contieneTodo -->
<?php get_footer();?>