<section class="estadisticas">
	<h2>
		ESTADISTICAS
	</h2>
	<div class="cajaEstadisticas">
		<iframe src="http://www.milb.com/milb/stats/stats.jsp?t=l_bat&lid=125&sid=l125" height="270" width="728" frameborder="0"></iframe> 
	</div>
</section>