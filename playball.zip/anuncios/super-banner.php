<section class="superBanner">
	<script type="text/javascript"><!--
        google_ad_client = "ca-pub-3477318490672713";
        /* Header */
        google_ad_slot = "2002888659";
        google_ad_width = 728;
        google_ad_height = 90;
        //-->
        </script>
        <script type="text/javascript"
        src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
    </script>
</section>