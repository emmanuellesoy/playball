<aside class="boxBanner">
	<script type="text/javascript"><!--
        google_ad_client = "ca-pub-3477318490672713";
        /* Box Banner */
        google_ad_slot = "5509945443";
        google_ad_width = 300;
        google_ad_height = 250;
        //-->
    </script>
    <script type="text/javascript"
        src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
    </script>
</aside>